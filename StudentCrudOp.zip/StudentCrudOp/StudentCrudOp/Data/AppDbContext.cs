﻿using Microsoft.EntityFrameworkCore;
using StudentCrudOp.Models;

namespace StudentCrudOp.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options): base(options) 
        {
            
        }
        public DbSet<Student> Students { get; set; }

        public DbSet<Login> Logins { get; set; }


    }
}
