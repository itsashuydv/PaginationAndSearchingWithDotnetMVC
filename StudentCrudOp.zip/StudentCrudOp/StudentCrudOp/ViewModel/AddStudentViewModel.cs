﻿using System.ComponentModel.DataAnnotations;

namespace StudentCrudOp.ViewModel
{
    public class AddStudentViewModel
    {
        [Required(ErrorMessage = "Name id Required")]
        public string? Name { get; set; }
        public DateOnly? DOB { get; set; }
        public string? Address { get; set; }
    }
}
