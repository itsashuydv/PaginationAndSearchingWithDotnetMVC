﻿using Microsoft.AspNetCore.Mvc;
using StudentCrudOp.Data;
using StudentCrudOp.Models;

namespace StudentCrudOp.Controllers
{
    public class AccountController : Controller
    {
        private readonly AppDbContext _dbContext;

        public AccountController( AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }


        public IActionResult Login()
        {
            return View();
        }

        [HttpPost("Login")]
        public IActionResult Login(Login login)
        {
            if (login != null)
            {
                var data = _dbContext.Logins.Where(x=>x.UserId == login.UserId && x.Password == login.Password).FirstOrDefault();
                if(data != null)
                {
                    return RedirectToAction("Index", "Student");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Invalid user ID or password.");

                    return View();
                }

            }
            ModelState.AddModelError(string.Empty, "Invalid user ID or password.");

            return View();
        }
    }
}
