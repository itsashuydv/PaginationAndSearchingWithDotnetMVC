﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentCrudOp.Data;
using StudentCrudOp.Models;


namespace StudentCrudOp.Controllers
{
    public class StudentController : Controller
    {
        private readonly AppDbContext _dbContext;

        public StudentController(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }


        [HttpGet("Index")]
        public IActionResult Index(int? page, int? pageSize, string search)
        {
            const int defaultPageSize = 5; 
            var students = _dbContext.Students.AsQueryable(); 

            
            students = SearchStudents(students, search);

            
            var paginatedStudents = PaginateStudents(students, page, pageSize, defaultPageSize);

            return View(paginatedStudents);
        }

        
        private IQueryable<Student> SearchStudents(IQueryable<Student> students, string search)
        {
            if (!string.IsNullOrEmpty(search))
            {
                var searchTerm = search.ToLower();

                students = students.Where(s =>
                    EF.Functions.Like(s.Name.ToLower(), $"%{searchTerm}%") ||
                    EF.Functions.Like(s.Address.ToLower(), $"%{searchTerm}%")
                );
            }
            return students;
        }


        private List<Student> PaginateStudents(IQueryable<Student> students, int? page, int? pageSize, int defaultPageSize)
        {
            var pageNumber = page ?? 1;
            var actualPageSize = pageSize ?? defaultPageSize;

            
            var totalRecords = students.Count();

           
            var pageCount = (int)Math.Ceiling(totalRecords / (double)actualPageSize);

            
            pageNumber = Math.Min(pageNumber, pageCount);

            
            var paginatedStudents = students.Skip((pageNumber - 1) * actualPageSize)
                                            .Take(actualPageSize)
                                            .ToList();

            ViewBag.PageNumber = pageNumber;
            ViewBag.PageCount = pageCount;
            ViewBag.PageSize = actualPageSize;

            return paginatedStudents;
        }




        [HttpGet("AddStudent")]
        public IActionResult AddStudent()
        {
            return View();

        }

        [HttpPost("AddStudent")]
        public IActionResult AddStudent(Student model)
        {
            if(ModelState.IsValid)
            {
                
                _dbContext.Students.Add(model);
                _dbContext.SaveChanges();

                return RedirectToAction("Index");
                
            }
            
            ModelState.AddModelError(string.Empty, "Student Details Invalid");
            return View();
           
        }

        [HttpGet("Edit")]
        public IActionResult Edit(int Id)
        {

            var student = _dbContext.Students.FirstOrDefault(x => x.Id == Id);
            if (student == null)
            {
                return NotFound(); 
            }
            return View(student);

        }

        [HttpPost("Edit")]
        public IActionResult Edit(Student student)
        {
            if (ModelState.IsValid)
            {
                // Update student record in the database
                var existingStudent = _dbContext.Students.Find(student.Id);
                if (existingStudent != null)
                {
                    existingStudent.Name = student.Name;
                    existingStudent.DOB = student.DOB;
                    existingStudent.Address = student.Address;
                    _dbContext.SaveChanges();
                    return RedirectToAction("Index", "Student"); // Redirect to student list after successful edit
                }
            }
            // If model state is not valid or student record not found, return back to the edit form
            return View(student);

        }

        [HttpPost("Delete")]
        public IActionResult Delete(int Id)
        {

            var data = _dbContext.Students.Where(x => x.Id == Id).FirstOrDefault();


            if(data != null)
            {
                _dbContext.Students.Remove(data);
                _dbContext.SaveChanges();
                return RedirectToAction("Index", "Student");

            }
            return View(data);
        }


    }
}
