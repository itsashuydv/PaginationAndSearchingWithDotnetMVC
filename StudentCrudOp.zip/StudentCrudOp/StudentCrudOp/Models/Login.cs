﻿using System.ComponentModel.DataAnnotations;

namespace StudentCrudOp.Models
{
    public class Login
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "User ID is required")]

        public string? UserId { get; set; }

        [Required(ErrorMessage = "Password is required")]

        public string? Password { get; set; }
    }
}
