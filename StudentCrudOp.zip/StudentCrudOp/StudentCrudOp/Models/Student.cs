﻿using System.ComponentModel.DataAnnotations;

namespace StudentCrudOp.Models
{
    public class Student
    {
        public int Id { get; set; }

        [Required(ErrorMessage ="Name id Required")]
        public string? Name { get; set; }
        [Required(ErrorMessage = "DOB id Required")]
        public DateOnly? DOB  { get; set; }
        public string? Address { get; set; }
    }
}
